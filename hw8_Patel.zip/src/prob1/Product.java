package prob1;

public class Product {
	private String code;
	
	public Product(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}
	
	@Override
	public String toString() {
		return "code=" + code;
	}
	public static void main(String [] args) {
		String str, str2;
		if(str.substring(0, 2) == str2.substring(0, 2)) {
			System.out.println(str.substring(0, 2));
		}
		else if(str.endsWith("t")) {
			System.out.println(str);
		}
		else {
			System.out.println("nothing");
		}
	}
	public void increaseTeleporterVolume(int idThreshold) {

		idThreshold++;
		return idThreshold;

		}

}
